# SVM-SpamBase
Support Vector Machine (Primal and Dual) in Matlab using quadprog
