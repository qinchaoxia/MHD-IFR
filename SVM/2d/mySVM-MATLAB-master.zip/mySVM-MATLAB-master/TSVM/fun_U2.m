function fz=fun_U2(z)
% U_2(z)=abs(z)-1
fz=abs(z)-1;
return