function fx=fun_fx(Xr,beta,beta0)
fx=Xr*beta+beta0;
return
