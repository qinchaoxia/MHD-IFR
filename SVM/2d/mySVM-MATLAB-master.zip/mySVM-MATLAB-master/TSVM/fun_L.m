function fz=fun_L(z)
% L(z)=U_1(z)-U_2(z)
fz=max(1-z,0);
return