function fz=fun_U1(z)
% U_1(z)=(abs(z)-1)_+
fz=max(abs(z)-1,0);
return